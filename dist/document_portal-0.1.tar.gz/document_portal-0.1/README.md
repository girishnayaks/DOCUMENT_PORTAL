# LLMOps
LLMOPS-Industry Ready Projects


### Minimum requirements (RAG Pipeline)

1. LLM Model ## Groq, OpenAI, Gemini, Claude, Huggingface
2. Embedding Model ## OpenAI, HuggingFace, Gemini
3. Vector Database ## Inmemory, Ondisk, Cloudbase
    a. Inmemory
    b. Ondisk
    c. Cloudbase
