from setuptools import setup, find_packages

setup(
    name="document_portal",
    author="Girish Nayak",
    version="0.1",
    packages=find_packages()
)